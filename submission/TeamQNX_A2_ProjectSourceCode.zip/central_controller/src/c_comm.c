/*
    RMIT University Vietnam
    Course: EEET2588 Real-Time System Engineering
    Semester: 2026-2
    Author: Team QNX
    Member: Tran Dong Nghi - s3914633
			Le Hung - s4061665
			Hoang Minh Thang - s3999925
    Assessment: 2 - Project Implementation 
    Due date: 18/09/2026
*/

#include <string.h>

#include "c_comm.h"
#include "c_logger.h"

// Implements the fire-and-forget four-step IPC send pattern for outgoing central commands.

static pthread_mutex_t *g_console_io_lock = NULL;

void c_comm_set_console_io_lock(pthread_mutex_t *lock)
{
    g_console_io_lock = lock;
}

static const char *verb_name(uint32_t verb)
{
    switch ((msg_type_t)verb) {
    case MSG_SET_TIMING_PROFILE:  return "SET_TIMING_PROFILE";
    case MSG_SET_MODE:            return "SET_MODE";
    case MSG_REQUEST_OVERRIDE:    return "REQUEST_OVERRIDE";
    case MSG_RENEW_OVERRIDE:      return "RENEW_OVERRIDE";
    case MSG_CANCEL_OVERRIDE:     return "CANCEL_OVERRIDE";
    case MSG_REQUEST_FAULT_CLEAR: return "REQUEST_FAULT_CLEAR";
    default:                      return "UNKNOWN_VERB";
    }
}

static const char *result_name(uint32_t result)
{
    switch ((msg_result_t)result) {
    case RESULT_ACK:         return "ACK";
    case RESULT_ACK_PENDING: return "ACK_PENDING";
    case RESULT_NACK:        return "NACK";
    case RESULT_ERROR:       return "ERROR";
    default:                 return "UNKNOWN_RESULT";
    }
}

static const char *nack_reason_name(uint32_t reason)
{
    switch ((nack_reason_t)reason) {
    case NACK_REASON_NONE:                    return "NONE";
    case NACK_REASON_INVALID_DURATION:        return "INVALID_DURATION";
    case NACK_REASON_RAILWAY_CONFLICT:        return "RAILWAY_CONFLICT";
    case NACK_REASON_PEDESTRIAN_ACTIVE:       return "PEDESTRIAN_ACTIVE";
    case NACK_REASON_FAULT_ACTIVE:            return "FAULT_ACTIVE";
    case NACK_REASON_STALE_OR_UNSAFE_PROFILE: return "STALE_OR_UNSAFE_PROFILE";
    case NACK_REASON_OUT_OF_RANGE:            return "OUT_OF_RANGE";
    case NACK_REASON_UNKNOWN_TARGET:          return "UNKNOWN_TARGET";
    default:                                  return "UNKNOWN_REASON";
    }
}

// Stateless, shared async reply handler that logs the outcome of outgoing IPC commands.
static void on_command_reply(controller_id_t target_id, const ipc_request_t *original_req, const ipc_reply_t *reply, int send_ok, void *ctx)
{
    (void)ctx;

    if (g_console_io_lock != NULL) {
        pthread_mutex_lock(g_console_io_lock);
    }

    if (!send_ok) {
        c_logger_log("C1: %s to %d send failed (peer unreachable or send error)",
                     verb_name(original_req->verb), (int)target_id);
    } else if ((msg_result_t)reply->result == RESULT_NACK) {
        c_logger_log("C1: %s to %d -> NACK reason=%s",
                     verb_name(original_req->verb), (int)target_id, nack_reason_name(reply->reason));
    } else {
        c_logger_log("C1: %s to %d -> %s",
                     verb_name(original_req->verb), (int)target_id, result_name(reply->result));
    }

    if (g_console_io_lock != NULL) {
        pthread_mutex_unlock(g_console_io_lock);
    }
}

void c_comm_send_set_mode(ipc_client_queue_t *q, controller_id_t target, operating_mode_t mode)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_SET_MODE;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;
    req.payload.mode.mode = (uint32_t)mode;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: SET_MODE to %d dropped - outgoing queue full or stopping", (int)target);
    }
}

void c_comm_broadcast_set_mode(ipc_client_queue_t *q, operating_mode_t mode)
{
    int i;

    for (i = 0; i < 6; i++) {
        c_comm_send_set_mode(q, (controller_id_t)(CTRL_L1 + i), mode);
    }
}

void c_comm_send_timing_profile(ipc_client_queue_t *q, controller_id_t target,
                                 uint32_t profile_id, uint32_t offset_ms)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_SET_TIMING_PROFILE;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;
    req.payload.timing_profile.profile_id = profile_id;
    req.payload.timing_profile.offset_ms  = offset_ms;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: SET_TIMING_PROFILE to %d dropped - outgoing queue full or stopping", (int)target);
    }
}

void c_comm_broadcast_timing_profile(ipc_client_queue_t *q, const c_arterial_offset_t *chain,
                                      int chain_len, uint32_t profile_id)
{
    ipc_request_t requests[8];
    int i;
    int n;

    if (chain == NULL || chain_len <= 0 || chain_len > (int)(sizeof(requests) / sizeof(requests[0]))) {
        c_logger_log("C1: SET_TIMING_PROFILE broadcast aborted - invalid chain (len=%d)", chain_len);
        return;
    }

    n = c_mode_eng_build_timing_profile(profile_id, chain, chain_len, requests);
    for (i = 0; i < n; i++) {
        controller_id_t target = (controller_id_t)requests[i].target_id;

        if (ipc_client_post(q, target, &requests[i], on_command_reply, NULL) != 0) {
            c_logger_log("C1: SET_TIMING_PROFILE (profile %u) to %d dropped - outgoing queue full or stopping",
                         (unsigned)profile_id, (int)target);
        }
    }
}

void c_comm_send_request_override(ipc_client_queue_t *q, controller_id_t target,
                                   uint32_t override_type, uint32_t target_movement, uint32_t duration_ms)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_REQUEST_OVERRIDE;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;
    req.payload.override_request.override_type   = override_type;
    req.payload.override_request.target_movement  = target_movement;
    req.payload.override_request.duration_ms      = duration_ms;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: REQUEST_OVERRIDE to %d dropped - outgoing queue full or stopping", (int)target);
    }
}

void c_comm_send_renew_override(ipc_client_queue_t *q, controller_id_t target, uint32_t extend_duration_ms)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_RENEW_OVERRIDE;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;
    req.payload.override_renew.extend_duration_ms = extend_duration_ms;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: RENEW_OVERRIDE to %d dropped - outgoing queue full or stopping", (int)target);
    }
}

void c_comm_send_cancel_override(ipc_client_queue_t *q, controller_id_t target)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_CANCEL_OVERRIDE;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: CANCEL_OVERRIDE to %d dropped - outgoing queue full or stopping", (int)target);
    }
}

void c_comm_send_request_fault_clear(ipc_client_queue_t *q, controller_id_t target)
{
    ipc_request_t req;

    memset(&req, 0, sizeof(req));
    req.verb         = MSG_REQUEST_FAULT_CLEAR;
    req.sender_id    = (uint32_t)CTRL_C1;
    req.target_id    = (uint32_t)target;
    req.timestamp_ms = 0;

    if (ipc_client_post(q, target, &req, on_command_reply, NULL) != 0) {
        c_logger_log("C1: REQUEST_FAULT_CLEAR to %d dropped - outgoing queue full or stopping", (int)target);
    }
}